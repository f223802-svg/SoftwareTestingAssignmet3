package org.example;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.UUID;

public final class Utils {
    private Utils() {
    }

    public static String generateId(String prefix) {
        if (prefix == null || prefix.isBlank()) {
            throw new IllegalArgumentException("Prefix must not be blank.");
        }
        return prefix + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT);
    }

    public static String formatCurrency(double amount) {
        return NumberFormat.getCurrencyInstance(Locale.US).format(amount);
    }

    public static void printHeading(String title) {
        System.out.println();
        System.out.println("=== " + title + " ===");
    }
}
