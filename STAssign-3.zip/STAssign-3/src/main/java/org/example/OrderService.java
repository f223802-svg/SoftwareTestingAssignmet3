package org.example;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderService {
    private final PaymentService paymentService;
    private final List<String> orders = new ArrayList<>();

    public OrderService(PaymentService paymentService) {
        if (paymentService == null) {
            throw new IllegalArgumentException("Payment service must not be null.");
        }
        this.paymentService = paymentService;
    }

    public String placeOrder(String userEmail, Cart cart, ProductService productService, String paymentMethod) {
        if (userEmail == null || userEmail.isBlank()) {
            throw new IllegalArgumentException("User email must not be blank.");
        }
        if (cart == null) {
            throw new IllegalArgumentException("Cart must not be null.");
        }
        if (productService == null) {
            throw new IllegalArgumentException("Product service must not be null.");
        }
        if (paymentMethod == null || paymentMethod.isBlank()) {
            throw new IllegalArgumentException("Payment method must not be blank.");
        }
        if (cart.isEmpty()) {
            throw new IllegalStateException("Cannot place an order with an empty cart.");
        }

        for (Map.Entry<String, Integer> entry : cart.getItems().entrySet()) {
            String productName = entry.getKey();
            int quantity = entry.getValue();
            if (quantity > productService.getStock(productName)) {
                throw new IllegalStateException("Insufficient stock for " + productName);
            }
        }

        double total = cart.calculateTotal(productService);
        boolean paymentSuccess = paymentService.processPayment(userEmail, total, paymentMethod);
        if (!paymentSuccess) {
            throw new IllegalStateException("Payment failed for order.");
        }

        for (Map.Entry<String, Integer> entry : cart.getItems().entrySet()) {
            productService.reduceStock(entry.getKey(), entry.getValue());
        }

        String orderId = Utils.generateId("ORD");
        String orderSummary = "Order ID: " + orderId
                + System.lineSeparator()
                + "User: " + userEmail
                + System.lineSeparator()
                + "Payment: " + paymentMethod
                + System.lineSeparator()
                + "Items: " + cart.getItems()
                + System.lineSeparator()
                + "Total: " + Utils.formatCurrency(total)
                + System.lineSeparator()
                + "Status: CONFIRMED";

        orders.add(orderSummary);
        cart.clear();
        return orderSummary;
    }

    public List<String> listOrders() {
        return Collections.unmodifiableList(new ArrayList<>(orders));
    }
}
