package org.example;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class UserService {
    private final Map<String, String> users = new LinkedHashMap<>();

    public void registerUser(String name, String email) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name must not be blank.");
        }
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email must not be blank.");
        }
        users.put(email, name);
    }

    public String getUserName(String email) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email must not be blank.");
        }
        String name = users.get(email);
        if (name == null) {
            throw new IllegalArgumentException("User not found: " + email);
        }
        return name;
    }

    public Map<String, String> listUsers() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(users));
    }
}
