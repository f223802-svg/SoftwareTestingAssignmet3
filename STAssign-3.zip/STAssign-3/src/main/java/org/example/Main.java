package org.example;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();
        ProductService productService = new ProductService();
        PaymentService paymentService = new PaymentService();
        OrderService orderService = new OrderService(paymentService);

        userService.registerUser("Ali Khan", "ali@example.com");

        productService.addProduct("Laptop", 1200.00, 5);
        productService.addProduct("Wireless Mouse", 25.50, 20);
        productService.addProduct("Mechanical Keyboard", 89.99, 10);

        Utils.printHeading("Available Products");
        for (String productName : productService.listProducts().keySet()) {
            System.out.println(
                    productName + " - "
                            + Utils.formatCurrency(productService.getPrice(productName))
                            + ", stock: " + productService.getStock(productName)
            );
        }

        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        cart.addProduct("Wireless Mouse", 2);
        cart.addProduct("Mechanical Keyboard", 1);

        Utils.printHeading("Cart Summary");
        System.out.println("User: " + userService.getUserName("ali@example.com"));
        System.out.println("Total: " + Utils.formatCurrency(cart.calculateTotal(productService)));

        String order = orderService.placeOrder("ali@example.com", cart, productService, "Credit Card");

        Utils.printHeading("Order Result");
        System.out.println(order);
    }
}
