package org.example;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {
    private final Map<String, Integer> items = new LinkedHashMap<>();

    public void addProduct(String productName, int quantity) {
        if (productName == null || productName.isBlank()) {
            throw new IllegalArgumentException("Product name must not be blank.");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }
        items.merge(productName, quantity, Integer::sum);
    }

    public Map<String, Integer> getItems() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(items));
    }

    public double calculateTotal(ProductService productService) {
        if (productService == null) {
            throw new IllegalArgumentException("Product service must not be null.");
        }
        double total = 0.0;
        for (Map.Entry<String, Integer> entry : items.entrySet()) {
            total += productService.getPrice(entry.getKey()) * entry.getValue();
        }
        return total;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public void clear() {
        items.clear();
    }
}
