package org.example;

public class PaymentService {
    public boolean processPayment(String userEmail, double amount, String paymentMethod) {
        if (userEmail == null || userEmail.isBlank()) {
            return false;
        }
        if (paymentMethod == null || paymentMethod.isBlank()) {
            return false;
        }
        if (amount <= 0) {
            return false;
        }

        System.out.println(
                "Processing " + Utils.formatCurrency(amount)
                        + " for " + userEmail
                        + " using " + paymentMethod
        );
        return true;
    }
}
