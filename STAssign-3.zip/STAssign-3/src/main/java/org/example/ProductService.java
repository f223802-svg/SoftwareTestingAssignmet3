package org.example;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class ProductService {
    private final Map<String, Double> prices = new LinkedHashMap<>();
    private final Map<String, Integer> stock = new LinkedHashMap<>();

    public void addProduct(String name, double price, int quantity) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name must not be blank.");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Price must not be negative.");
        }
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must not be negative.");
        }
        prices.put(name, price);
        stock.put(name, quantity);
    }

    public double getPrice(String productName) {
        if (productName == null || productName.isBlank()) {
            throw new IllegalArgumentException("Product name must not be blank.");
        }
        Double price = prices.get(productName);
        if (price == null) {
            throw new IllegalArgumentException("Product not found: " + productName);
        }
        return price;
    }

    public int getStock(String productName) {
        if (productName == null || productName.isBlank()) {
            throw new IllegalArgumentException("Product name must not be blank.");
        }
        Integer quantity = stock.get(productName);
        if (quantity == null) {
            throw new IllegalArgumentException("Product not found: " + productName);
        }
        return quantity;
    }

    public void reduceStock(String productName, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }
        int available = getStock(productName);
        if (quantity > available) {
            throw new IllegalArgumentException("Not enough stock for " + productName);
        }
        stock.put(productName, available - quantity);
    }

    public Map<String, Double> listProducts() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(prices));
    }
}
