package org.example;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("integration")
@TestMethodOrder(OrderAnnotation.class)
class MainTest {

    @Test
    @Order(1)
    void should_printOrderSummary_when_mainRuns() {
        // Arrange
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));

        // Act
        try {
            Main.main(new String[0]);
        } finally {
            System.setOut(originalOut);
        }

        // Assert
        String output = outputStream.toString();
        assertTrue(output.contains("Available Products"));
        assertTrue(output.contains("Order Result"));
    }
}
