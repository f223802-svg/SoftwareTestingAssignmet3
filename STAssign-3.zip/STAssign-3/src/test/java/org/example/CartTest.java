package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("fast")
@TestMethodOrder(OrderAnnotation.class)
class CartTest {

    @Test
    @Order(1)
    void should_addNewItem_when_productAndQuantityValid() {
        // Arrange
        Cart cart = new Cart();

        // Act
        cart.addProduct("Laptop", 1);

        // Assert
        assertEquals(1, cart.getItems().get("Laptop"));
    }

    @Test
    @Order(2)
    void should_accumulateQuantity_when_sameProductAddedTwice() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);

        // Act
        cart.addProduct("Laptop", 2);

        // Assert
        assertEquals(3, cart.getItems().get("Laptop"));
    }

    @Test
    @Order(3)
    void should_throwException_when_addProductWithBlankName() {
        // Arrange
        Cart cart = new Cart();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> cart.addProduct(" ", 1));

        // Assert
        assertEquals("Product name must not be blank.", exception.getMessage());
    }

    @Test
    @Order(4)
    void should_throwException_when_addProductWithZeroQuantity() {
        // Arrange
        Cart cart = new Cart();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> cart.addProduct("Laptop", 0));

        // Assert
        assertEquals("Quantity must be greater than zero.", exception.getMessage());
    }

    @Test
    @Order(5)
    void should_returnTrue_when_cartIsEmpty() {
        // Arrange
        Cart cart = new Cart();

        // Act
        boolean actual = cart.isEmpty();

        // Assert
        assertTrue(actual);
    }

    @Test
    @Order(6)
    void should_returnFalse_when_cartHasItems() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);

        // Act
        boolean actual = cart.isEmpty();

        // Assert
        assertFalse(actual);
    }

    @Test
    @Order(7)
    void should_calculateTotal_when_productsExistInCatalog() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        productService.addProduct("Mouse", 25.00, 10);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        cart.addProduct("Mouse", 2);

        // Act
        double actual = cart.calculateTotal(productService);

        // Assert
        assertEquals(1250.00, actual);
    }

    @Test
    @Order(8)
    void should_returnZeroTotal_when_cartIsEmpty() {
        // Arrange
        Cart cart = new Cart();
        ProductService productService = new ProductService();

        // Act
        double actual = cart.calculateTotal(productService);

        // Assert
        assertEquals(0.0, actual);
    }

    @Test
    @Order(9)
    void should_throwException_when_calculateTotalWithNullProductService() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> cart.calculateTotal(null));

        // Assert
        assertEquals("Product service must not be null.", exception.getMessage());
    }

    @Test
    @Order(10)
    void should_throwException_when_calculateTotalForUnknownProduct() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> cart.calculateTotal(productService));

        // Assert
        assertTrue(exception.getMessage().contains("Product not found"));
    }

    @Test
    @Order(11)
    void should_clearItems_when_clearCalled() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);

        // Act
        cart.clear();

        // Assert
        assertTrue(cart.isEmpty());
    }

    @Test
    @Order(12)
    void should_returnUnmodifiableSnapshot_when_getItemsCalled() {
        // Arrange
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        Map<String, Integer> items = cart.getItems();

        // Act
        UnsupportedOperationException exception =
                assertThrows(UnsupportedOperationException.class, () -> items.put("Mouse", 2));

        // Assert
        assertTrue(exception != null);
    }
}
