package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("fast")
@TestMethodOrder(OrderAnnotation.class)
class UtilsTest {

    @Test
    @Order(1)
    void should_generatePrefixedId_when_prefixIsValid() {
        // Arrange
        String prefix = "ORD";

        // Act
        String id = Utils.generateId(prefix);

        // Assert
        assertTrue(id.startsWith("ORD-"));
        assertEquals(12, id.length());
    }

    @Test
    @Order(2)
    void should_throwException_when_prefixIsBlank() {
        // Arrange

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> Utils.generateId(" "));

        // Assert
        assertEquals("Prefix must not be blank.", exception.getMessage());
    }

    @Test
    @Order(3)
    void should_formatCurrency_when_amountIsValid() {
        // Arrange

        // Act
        String formatted = Utils.formatCurrency(1340.99);

        // Assert
        assertEquals("$1,340.99", formatted);
    }

    @Test
    @Order(4)
    void should_printHeading_when_titleProvided() {
        // Arrange
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));

        // Act
        try {
            Utils.printHeading("Cart Summary");
        } finally {
            System.setOut(originalOut);
        }

        // Assert
        assertTrue(outputStream.toString().contains("=== Cart Summary ==="));
    }
}
