package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("fast")
@TestMethodOrder(OrderAnnotation.class)
class ProductServiceTest {

    @Test
    @Order(1)
    void should_storeProductDetails_when_addProductWithValidData() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        productService.addProduct("Laptop", 1200.00, 5);

        // Assert
        assertEquals(1200.00, productService.getPrice("Laptop"));
        assertEquals(5, productService.getStock("Laptop"));
    }

    @Test
    @Order(2)
    void should_replaceExistingProduct_when_addProductUsesExistingName() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);

        // Act
        productService.addProduct("Laptop", 1300.00, 3);

        // Assert
        assertEquals(1300.00, productService.getPrice("Laptop"));
        assertEquals(3, productService.getStock("Laptop"));
    }

    @Test
    @Order(3)
    void should_throwException_when_addProductWithBlankName() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.addProduct(" ", 10.0, 1));

        // Assert
        assertEquals("Product name must not be blank.", exception.getMessage());
    }

    @Test
    @Order(4)
    void should_throwException_when_addProductWithNegativePrice() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.addProduct("Mouse", -1.0, 1));

        // Assert
        assertEquals("Price must not be negative.", exception.getMessage());
    }

    @Test
    @Order(5)
    void should_throwException_when_addProductWithNegativeQuantity() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.addProduct("Mouse", 10.0, -1));

        // Assert
        assertEquals("Quantity must not be negative.", exception.getMessage());
    }

    @Test
    @Order(6)
    void should_throwException_when_getPriceForUnknownProduct() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.getPrice("Unknown"));

        // Assert
        assertTrue(exception.getMessage().contains("Product not found"));
    }

    @Test
    @Order(7)
    void should_throwException_when_getStockForUnknownProduct() {
        // Arrange
        ProductService productService = new ProductService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.getStock("Unknown"));

        // Assert
        assertTrue(exception.getMessage().contains("Product not found"));
    }

    @Test
    @Order(8)
    void should_reduceStock_when_quantityWithinAvailable() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Keyboard", 90.00, 10);

        // Act
        productService.reduceStock("Keyboard", 4);

        // Assert
        assertEquals(6, productService.getStock("Keyboard"));
    }

    @Test
    @Order(9)
    void should_setStockToZero_when_reduceStockMatchesAvailable() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Keyboard", 90.00, 4);

        // Act
        productService.reduceStock("Keyboard", 4);

        // Assert
        assertEquals(0, productService.getStock("Keyboard"));
    }

    @Test
    @Order(10)
    void should_throwException_when_reduceStockExceedsAvailable() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Keyboard", 90.00, 4);

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.reduceStock("Keyboard", 5));

        // Assert
        assertEquals("Not enough stock for Keyboard", exception.getMessage());
    }

    @Test
    @Order(11)
    void should_throwException_when_reduceStockWithNonPositiveQuantity() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Keyboard", 90.00, 4);

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> productService.reduceStock("Keyboard", 0));

        // Assert
        assertEquals("Quantity must be greater than zero.", exception.getMessage());
    }

    @Test
    @Order(12)
    void should_returnUnmodifiableSnapshot_when_listProductsCalled() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        Map<String, Double> products = productService.listProducts();

        // Act
        UnsupportedOperationException exception =
                assertThrows(UnsupportedOperationException.class, () -> products.put("Mouse", 25.00));

        // Assert
        assertTrue(exception != null);
    }
}
