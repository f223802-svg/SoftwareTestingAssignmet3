package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

@Tag("fast")
@TestMethodOrder(OrderAnnotation.class)
class PaymentServiceCsvFileTest {

    @ParameterizedTest(name = "[{index}] expected {3} for {0} / {1} / {2}")
    @CsvFileSource(resources = "/data/payment-cases.csv", numLinesToSkip = 1)
    @Order(1)
    void should_matchExpectedOutcome_when_processingPaymentFromCsv(
            String userEmail,
            double amount,
            String paymentMethod,
            boolean expected
    ) {
        // Arrange
        PaymentService paymentService = new PaymentService();

        // Act
        boolean actual = paymentService.processPayment(userEmail, amount, paymentMethod);

        // Assert
        assertEquals(expected, actual);
    }
}
