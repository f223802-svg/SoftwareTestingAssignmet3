package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("integration")
@TestMethodOrder(OrderAnnotation.class)
class OrderServiceTest {

    @Test
    @Order(1)
    void should_throwException_when_constructorReceivesNullPaymentService() {
        // Arrange

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> new OrderService(null));

        // Assert
        assertEquals("Payment service must not be null.", exception.getMessage());
    }

    @Test
    @Order(2)
    void should_createConfirmedOrder_when_paymentSucceeds() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        String order = orderService.placeOrder("ali@example.com", cart, productService, "Credit Card");

        // Assert
        assertTrue(order.contains("Status: CONFIRMED"));
    }

    @Test
    @Order(3)
    void should_storeOrder_when_orderPlaced() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        orderService.placeOrder("ali@example.com", cart, productService, "Credit Card");
        List<String> orders = orderService.listOrders();

        // Assert
        assertEquals(1, orders.size());
    }

    @Test
    @Order(4)
    void should_clearCart_when_orderPlaced() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        orderService.placeOrder("ali@example.com", cart, productService, "Credit Card");

        // Assert
        assertTrue(cart.isEmpty());
    }

    @Test
    @Order(5)
    void should_reduceProductStock_when_orderPlaced() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 5);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 2);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        orderService.placeOrder("ali@example.com", cart, productService, "Credit Card");

        // Assert
        assertEquals(3, productService.getStock("Laptop"));
    }

    @Test
    @Order(6)
    void should_throwException_when_placeOrderWithBlankUserEmail() {
        // Arrange
        ProductService productService = new ProductService();
        Cart cart = new Cart();
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> orderService.placeOrder(" ", cart, productService, "Card"));

        // Assert
        assertEquals("User email must not be blank.", exception.getMessage());
    }

    @Test
    @Order(7)
    void should_throwException_when_placeOrderWithNullCart() {
        // Arrange
        ProductService productService = new ProductService();
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> orderService.placeOrder("ali@example.com", null, productService, "Card"));

        // Assert
        assertEquals("Cart must not be null.", exception.getMessage());
    }

    @Test
    @Order(8)
    void should_throwException_when_placeOrderWithBlankPaymentMethod() {
        // Arrange
        ProductService productService = new ProductService();
        Cart cart = new Cart();
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class,
                        () -> orderService.placeOrder("ali@example.com", cart, productService, " "));

        // Assert
        assertEquals("Payment method must not be blank.", exception.getMessage());
    }

    @Test
    @Order(9)
    void should_throwException_when_cartIsEmpty() {
        // Arrange
        ProductService productService = new ProductService();
        Cart cart = new Cart();
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        IllegalStateException exception =
                assertThrows(IllegalStateException.class,
                        () -> orderService.placeOrder("ali@example.com", cart, productService, "Card"));

        // Assert
        assertEquals("Cannot place an order with an empty cart.", exception.getMessage());
    }

    @Test
    @Order(10)
    void should_throwException_when_stockIsInsufficient() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 1);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 2);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());

        // Act
        IllegalStateException exception =
                assertThrows(IllegalStateException.class,
                        () -> orderService.placeOrder("ali@example.com", cart, productService, "Card"));

        // Assert
        assertEquals("Insufficient stock for Laptop", exception.getMessage());
    }

    @Test
    @Order(11)
    void should_throwException_when_paymentFails() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 1);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        OrderService orderService = new OrderService(new FailedPaymentService());

        // Act
        IllegalStateException exception =
                assertThrows(IllegalStateException.class,
                        () -> orderService.placeOrder("ali@example.com", cart, productService, "Card"));

        // Assert
        assertEquals("Payment failed for order.", exception.getMessage());
    }

    @Test
    @Order(12)
    void should_returnUnmodifiableSnapshot_when_listOrdersCalled() {
        // Arrange
        ProductService productService = new ProductService();
        productService.addProduct("Laptop", 1200.00, 1);
        Cart cart = new Cart();
        cart.addProduct("Laptop", 1);
        OrderService orderService = new OrderService(new SuccessfulPaymentService());
        orderService.placeOrder("ali@example.com", cart, productService, "Card");
        List<String> orders = orderService.listOrders();

        // Act
        UnsupportedOperationException exception =
                assertThrows(UnsupportedOperationException.class, () -> orders.add("manual"));

        // Assert
        assertTrue(exception != null);
    }

    private static final class SuccessfulPaymentService extends PaymentService {
        @Override
        public boolean processPayment(String userEmail, double amount, String paymentMethod) {
            return true;
        }
    }

    private static final class FailedPaymentService extends PaymentService {
        @Override
        public boolean processPayment(String userEmail, double amount, String paymentMethod) {
            return false;
        }
    }
}
