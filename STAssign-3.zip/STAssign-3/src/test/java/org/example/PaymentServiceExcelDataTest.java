package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@Tag("slow")
@TestMethodOrder(OrderAnnotation.class)
class PaymentServiceExcelDataTest {

    @ParameterizedTest(name = "[{index}] {0} / {1}")
    @MethodSource("paymentCasesFromWorkbook")
    @Order(1)
    void should_matchExpectedOutcome_when_processingPaymentFromExcel(
            String sheetName,
            String description,
            String userEmail,
            double amount,
            String paymentMethod,
            boolean expected
    ) {
        // Arrange
        PaymentService paymentService = new PaymentService();

        // Act
        boolean actual = paymentService.processPayment(userEmail, amount, paymentMethod);

        // Assert
        assertEquals(expected, actual, sheetName + " -> " + description);
    }

    static Stream<Arguments> paymentCasesFromWorkbook() {
        List<Arguments> arguments = new ArrayList<>();

        try (InputStream inputStream = PaymentServiceExcelDataTest.class.getResourceAsStream("/data/payment-cases.xlsx")) {
            if (inputStream == null) {
                throw new IllegalStateException("Missing Excel test data file.");
            }

            try (Workbook workbook = new XSSFWorkbook(inputStream)) {
                for (String sheetName : List.of("VALID", "INVALID", "EDGE", "STRESS")) {
                    Sheet sheet = workbook.getSheet(sheetName);
                    if (sheet == null) {
                        throw new IllegalStateException("Missing sheet: " + sheetName);
                    }

                    boolean headerRow = true;
                    for (Row row : sheet) {
                        if (headerRow) {
                            headerRow = false;
                            continue;
                        }

                        arguments.add(Arguments.of(
                                sheetName,
                                row.getCell(0).getStringCellValue(),
                                row.getCell(1).getStringCellValue(),
                                row.getCell(2).getNumericCellValue(),
                                row.getCell(3).getStringCellValue(),
                                row.getCell(4).getBooleanCellValue()
                        ));
                    }
                }
            }
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to read Excel test data", exception);
        }

        return arguments.stream();
    }
}
