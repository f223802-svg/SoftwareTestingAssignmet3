package org.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@Tag("fast")
@TestMethodOrder(OrderAnnotation.class)
class UserServiceTest {

    @Test
    @Order(1)
    void should_storeUser_when_registerUserWithValidData() {
        // Arrange
        UserService userService = new UserService();

        // Act
        userService.registerUser("Ali Khan", "ali@example.com");

        // Assert
        assertEquals("Ali Khan", userService.getUserName("ali@example.com"));
    }

    @Test
    @Order(2)
    void should_replaceExistingName_when_registerUserUsesExistingEmail() {
        // Arrange
        UserService userService = new UserService();
        userService.registerUser("Ali Khan", "ali@example.com");

        // Act
        userService.registerUser("Ali Raza", "ali@example.com");

        // Assert
        assertEquals("Ali Raza", userService.getUserName("ali@example.com"));
    }

    @Test
    @Order(3)
    void should_returnUserName_when_emailExists() {
        // Arrange
        UserService userService = new UserService();
        userService.registerUser("Sara Ahmed", "sara@example.com");

        // Act
        String actual = userService.getUserName("sara@example.com");

        // Assert
        assertEquals("Sara Ahmed", actual);
    }

    @Test
    @Order(4)
    void should_throwException_when_getUserNameForUnknownEmail() {
        // Arrange
        UserService userService = new UserService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> userService.getUserName("missing@example.com"));

        // Assert
        assertTrue(exception.getMessage().contains("User not found"));
    }

    @Test
    @Order(5)
    void should_throwException_when_registerUserWithBlankName() {
        // Arrange
        UserService userService = new UserService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> userService.registerUser(" ", "ali@example.com"));

        // Assert
        assertEquals("Name must not be blank.", exception.getMessage());
    }

    @Test
    @Order(6)
    void should_throwException_when_registerUserWithBlankEmail() {
        // Arrange
        UserService userService = new UserService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> userService.registerUser("Ali Khan", " "));

        // Assert
        assertEquals("Email must not be blank.", exception.getMessage());
    }

    @Test
    @Order(7)
    void should_throwException_when_getUserNameWithBlankEmail() {
        // Arrange
        UserService userService = new UserService();

        // Act
        IllegalArgumentException exception =
                assertThrows(IllegalArgumentException.class, () -> userService.getUserName(""));

        // Assert
        assertEquals("Email must not be blank.", exception.getMessage());
    }

    @Test
    @Order(8)
    void should_returnEmptyMap_when_noUsersRegistered() {
        // Arrange
        UserService userService = new UserService();

        // Act
        Map<String, String> users = userService.listUsers();

        // Assert
        assertTrue(users.isEmpty());
    }

    @Test
    @Order(9)
    void should_returnUnmodifiableSnapshot_when_listUsersCalled() {
        // Arrange
        UserService userService = new UserService();
        userService.registerUser("Ali Khan", "ali@example.com");
        Map<String, String> users = userService.listUsers();

        // Act
        UnsupportedOperationException exception =
                assertThrows(UnsupportedOperationException.class, () -> users.put("new@example.com", "New User"));

        // Assert
        assertTrue(exception != null);
    }
}
