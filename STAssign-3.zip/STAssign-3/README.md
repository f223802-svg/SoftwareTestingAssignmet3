# STAssign-3

This project is a small Java 21 Maven application that simulates a simple online shopping flow. It includes user registration, product catalog management, cart handling, payment processing, and order placement. The codebase is intentionally compact and is supported by a structured JUnit 5 test suite with coverage checks through JaCoCo.

## What the project does

The application walks through a basic e-commerce scenario:

- register a user
- add products to a catalog
- place products in a cart
- calculate the cart total
- process payment
- create a confirmed order and reduce stock

The entry point is `org.example.Main`, which runs a sample scenario and prints the result to the console.

## Project structure

```text
src/
  main/
    java/org/example/
      Main.java
      UserService.java
      ProductService.java
      Cart.java
      PaymentService.java
      OrderService.java
      Utils.java
  test/
    java/org/example/
      * unit and data-driven tests
    java/org/example/suite/
      FastTestSuite.java
      SlowTestSuite.java
      IntegrationTestSuite.java
    resources/data/
      payment-cases.csv
      payment-cases.xlsx
```

## Main components

`UserService` stores registered users and supports lookup by email.

`ProductService` manages product prices and stock, and validates inventory updates.

`Cart` stores selected items, merges duplicate additions, and calculates totals using the product catalog.

`PaymentService` performs basic payment validation and simulates payment processing.

`OrderService` validates the order, checks stock, processes payment, reduces inventory, stores the order summary, and clears the cart.

`Utils` contains small helper methods for IDs, headings, and currency formatting.

## Requirements

- Java 21
- Maven 3.9 or later

To confirm your setup:

```bash
java -version
mvn -version
```

## How to run the project

Compile the project:

```bash
mvn compile
```

Run the sample application:

```bash
java -cp target/classes org.example.Main
```

This works after `mvn compile` because the application has no external runtime dependencies.

## Testing

This project uses:

- JUnit 5
- JUnit Platform Suite
- Apache POI for Excel-backed test data
- JaCoCo for coverage reporting and minimum coverage checks

Run all tests:

```bash
mvn test
```

Run the full verification pipeline, including JaCoCo coverage checks:

```bash
mvn verify
```

Run only the fast suite:

```bash
mvn test "-Dtest=org.example.suite.FastTestSuite"
```

Run only the slow suite:

```bash
mvn test "-Dtest=org.example.suite.SlowTestSuite"
```

Run only the integration suite:

```bash
mvn test "-Dtest=org.example.suite.IntegrationTestSuite"
```

If you are using PowerShell, keep the `-Dtest=...` value quoted as shown above.

## Test design summary

The automated tests cover the core business logic as well as data-driven payment cases.

- unit tests target `UserService`, `ProductService`, `Cart`, `OrderService`, and `Utils`
- CSV-backed parameterized tests validate payment outcomes from flat-file data
- Excel-backed parameterized tests validate payment scenarios across `VALID`, `INVALID`, `EDGE`, and `STRESS` sheets
- integration coverage includes execution of the `Main` workflow
- test classes use ordered execution and tagging for suite selection

JaCoCo is configured to fail the build if line coverage or branch coverage drops below `70%`.

## Notes

- Currency formatting uses the US locale.
- Tests are configured for parallel execution at the class level.
- Generated reports and compiled artifacts are written to the `target/` directory.

## Verified status

The project was checked with:

```bash
mvn test
mvn verify
mvn test "-Dtest=org.example.suite.FastTestSuite"
mvn compile
java -cp target/classes org.example.Main
```

All of these commands completed successfully in this repository.
